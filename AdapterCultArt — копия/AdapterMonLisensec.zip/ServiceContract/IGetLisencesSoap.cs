﻿using AdapterMonListOfTourizm.DataContract;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XRoadLib.Attributes;

namespace AdapterMonListOfTourizm.ServiceContract
{
    public interface IGetLisencesSoap
    {

        [XRoadService("GetListOfProtMonum", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестр объектов произведений культуры и искусства")]
        ListOfProtMonum[] GetListOfObjCult(int year);


        [XRoadService("GetListOfRntObject", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестр по предоставлению в аренду зданий, помещений")]
        ListOfRntObject[] GetListOfRntRoomObject(int year);



        [XRoadService("GetListOfTZY", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестр театрально-зрелищных учреждений")]
        ListOfTZY[] GetListOfTZY(int year);

        [XRoadService("GetListOfStateAward", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестр государственных и ведомственных наград")]
        ListOfStateAward[] GetListOfStateAward(int year);


        [XRoadService("GetListOfProtMonum", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестр охраняемых объектов культурного наследия")]
        ListOfProtMonum[] GetListOfProtMonum(int year);

        [XRoadService("GetListOfLibOrg", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестр библиотек КР")]
        ListOfLibOrg[] GetListOfLibOrg(int year);


        [XRoadService("GetListOfEduOrg", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестр учебных организаций")]
        ListOfEduOrg[] GetListOfEduOrg(int year);

        [XRoadService("ListOfCinemaOrg", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестр киноорганизации")]
        ListOfCinemaOrg[] GetListOfCinemaOrg(int year);


        [XRoadService("GetListOfCinemaDocs", AddedInVersion = 1)]
        [XRoadTitle("RU", "Предоставление информации о перечне документов")]
        ListOfCinemaDocs[] GetListOfCinemaDocs(int year);

        [XRoadService("GetListOfCinemaCert", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестр по предоставлению прокатных удостоверений")]
        ListOfCinemaCert[] GetListOfCinemaCert(int year);

        [XRoadService("GetListOfEvtObj", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестро по предоставлению залов, помещений и т.д.")]
        ListOfEvtObj[] GetListOfEvtObj(int year);

        [XRoadService("GetListOfRntObject", AddedInVersion = 1)]
        [XRoadTitle("RU", "Реестро по предоставлению залов, помещений и т.д.")]
        ListOfRntObject[] GetListOfRntObject(int year);

        [XRoadService("GetListOfMonuments", AddedInVersion = 1)]
        [XRoadTitle("RU", "Сервис для получения получения списков памятников по годам")]
        ListOfMonument[] GetListOfMonuments(int year);
        // List<ListOfMonument> GetListOfMonuments(int year);

        [XRoadService("GetListOfTourizmIndicators", AddedInVersion = 1)]
        [XRoadTitle("RU", "Сервис для получения получения показателя туристического индикатора по году")]
        ListIndicatorsOfTourizm GetListOfTourizmIndicators(int year);


        [XRoadService("GetListOfTourizm", AddedInVersion = 1)]
        [XRoadTitle("RU", "Сервис для получения туристического агенства по пину")]
        ListOfTourizm GetListOfTourizm(AddRequest request);
        [XRoadService("GetListOfCinematografy", AddedInVersion = 1)]
        [XRoadTitle("RU", "Сервис для киноорганизация по пину")]
        ListOfCinematographys GetListOfCinematografy(AddRequest request);

        [XRoadService("GetListOfMedias", AddedInVersion = 1)]
        [XRoadTitle("RU", "Сервис для получения выданных разрешений СМИ по пин")]
        ListOfMedias GetListOfMedias(AddRequest request);
    }

    //public interface IPersonSoapService
    //{
    //    [XRoadService("GetPerson", AddedInVersion = 1)]
    //    [XRoadTitle("RU", "Сервис для выдачи персональных данных по пин")]
    //    PersonModel GetPerson(string pin);
    //}
}
