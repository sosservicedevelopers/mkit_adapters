﻿using System;
using System.Collections.Generic;

namespace AdapterLibrary
{
    public partial class DictMediaDistribTerritory
    {
        public int Id { get; set; }
        public string NameRus { get; set; }
        public string NameKyrg { get; set; }
    }
}
