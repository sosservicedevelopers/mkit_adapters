﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdapterLibrary
{
    //public class ApplicationContext : DbContext
    //{
        

    //    public ApplicationContext()
    //    {
    //        Database.EnsureCreated();
    //    }

    //    //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    //    //{
    //    //    optionsBuilder.UseNpgsql("Server=212.112.106.181;Port=5432;Database=aismkitdb;Username=postgres;Password=dbPwdAdmin");
    //    //}
    //}
    public class Context
    {
    }
}
